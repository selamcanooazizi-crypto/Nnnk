package wexaware.event;

public class EventGameUpdate extends Event {
}
