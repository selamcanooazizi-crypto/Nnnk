package wexaware.event.list;

import wexaware.event.Event;

public class TabCompleteEvent extends Event {
   private final String prefix;
   public String[] completions;

   public TabCompleteEvent(String prefix) {
      this.prefix = prefix;
   }

   public String getPrefix() {
      return this.prefix;
   }

   public void setCompletions(String[] completions) {
      this.completions = completions;
   }
}
