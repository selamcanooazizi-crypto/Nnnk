package wexaware.event.list;

import wexaware.event.Event;

public class EventCloseInv extends Event {
}
