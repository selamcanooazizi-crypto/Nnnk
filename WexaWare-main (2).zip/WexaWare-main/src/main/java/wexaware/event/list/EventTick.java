package wexaware.event.list;

import wexaware.event.Event;

public class EventTick extends Event {
}
