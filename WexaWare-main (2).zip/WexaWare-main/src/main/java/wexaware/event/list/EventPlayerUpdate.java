package wexaware.event.list;

import wexaware.event.Event;

public class EventPlayerUpdate extends Event {
}
