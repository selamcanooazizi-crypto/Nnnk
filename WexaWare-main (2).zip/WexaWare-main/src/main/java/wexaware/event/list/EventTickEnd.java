package wexaware.event.list;

import wexaware.event.Event;

public class EventTickEnd extends Event {
}
