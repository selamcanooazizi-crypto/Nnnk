package wexaware.event.list;

import wexaware.event.Event;

public class EventSprintSync extends Event {
}
