package wexaware.event.list;

import wexaware.event.Event;

public class EventMinecraftInit extends Event {
}
