package wexaware.event.list;

import wexaware.event.Event;

public class EventPlayerSync extends Event {
}
