package wexaware.event.list;

import lombok.Generated;
import net.minecraft.entity.Entity;
import wexaware.event.Event;

public class EventEntitySpawn extends Event {
   private final Entity entity;

   @Generated
   public Entity getEntity() {
      return this.entity;
   }

   @Generated
   public EventEntitySpawn(Entity entity) {
      this.entity = entity;
   }
}
