package wexaware.event.list;

import wexaware.event.Event;

public class EventAttackBlock extends Event {
}
