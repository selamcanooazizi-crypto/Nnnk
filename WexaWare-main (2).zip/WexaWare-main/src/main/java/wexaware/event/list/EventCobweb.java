package wexaware.event.list;

import wexaware.event.Event;

public class EventCobweb extends Event {
}
