package wexaware.event.list;

import wexaware.event.Event;

public class EventNoSlow extends Event {
}
