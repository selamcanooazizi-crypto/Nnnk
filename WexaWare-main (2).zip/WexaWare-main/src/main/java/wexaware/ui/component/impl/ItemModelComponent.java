package wexaware.ui.component.impl;

import java.util.function.Consumer;
import net.minecraft.client.util.math.MatrixStack;
import wexaware.module.settings.ItemModelSetting;
import wexaware.ui.component.Component;
import wexaware.util.cursor.CursorManager;
import wexaware.util.render.helper.HoverUtil;
import wexaware.util.render.msdf.Fonts;
import wexaware.util.render.providers.ColorProvider;
import wexaware.util.render.renderers.DrawUtil;

public class ItemModelComponent extends Component {
   private static final float ROW_HEIGHT = 18.0F;
   private static final float PADDING = 4.5F;
   private final ItemModelSetting setting;
   private final Consumer<ItemModelSetting> galleryOpener;

   public ItemModelComponent(ItemModelSetting setting, Consumer<ItemModelSetting> galleryOpener) {
      this.setting = setting;
      this.galleryOpener = galleryOpener;
      this.setHeight(20.0F);
   }

   @Override
   public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
      float alpha = Math.max(0.0F, Math.min(1.0F, this.getAlphaAnimSetting().getValue() * this.getAlphaAnim().getValue()));
      this.setHeight(20.0F * this.getAlphaAnimSetting().getValue());
      if (!(alpha < 0.02F)) {
         float rowX = this.x + 4.5F;
         float rowY = this.y + 1.0F;
         float rowW = this.width - 9.0F;
         boolean hovered = HoverUtil.isHovered((double)mouseX, (double)mouseY, (double)rowX, (double)rowY, (double)rowW, 18.0);
         if (hovered) {
            CursorManager.requestHand();
         }

         int alphaInt = (int)(255.0F * alpha);
         int border = hovered
            ? ColorProvider.setAlpha(ColorProvider.getColorClient(), (int)(150.0F * alpha))
            : ColorProvider.rgba(48, 66, 122, (float)((int)(90.0F * alpha)));
         DrawUtil.drawRound(rowX - 0.5F, rowY - 0.5F, rowW + 1.0F, 19.0F, 2.5F, border);
         DrawUtil.drawRound(rowX, rowY, rowW, 18.0F, 2.0F, ColorProvider.setAlpha(ColorProvider.getColorInactiveButton(), alphaInt));
         DrawUtil.drawText(Fonts.SFREGULAR.get(), "Model", rowX + 4.0F, rowY + 5.1F, ColorProvider.setAlpha(ColorProvider.getColorText(), alphaInt), 7.5F);
         String value = this.fitValue(this.setting.getValue(), rowW - 42.0F);
         float valueWidth = Fonts.SFREGULAR.get().getWidth(value, 6.5F);
         DrawUtil.drawText(
            Fonts.SFREGULAR.get(),
            value,
            rowX + rowW - valueWidth - 4.0F,
            rowY + 5.5F,
            ColorProvider.setAlpha(ColorProvider.getColorInactiveText(), alphaInt),
            6.5F
         );
      }
   }

   private String fitValue(String value, float maxWidth) {
      if (Fonts.SFREGULAR.get().getWidth(value, 6.5F) <= maxWidth) {
         return value;
      } else {
         String shortened = value;

         while (shortened.length() > 1 && Fonts.SFREGULAR.get().getWidth(shortened + "...", 6.5F) > maxWidth) {
            shortened = shortened.substring(0, shortened.length() - 1);
         }

         return shortened + "...";
      }
   }

   @Override
   public void mouseClicked(double mouseX, double mouseY, int button) {
      if (button == 0 && HoverUtil.isHovered(mouseX, mouseY, (double)(this.x + 4.5F), (double)(this.y + 1.0F), (double)(this.width - 9.0F), 18.0)) {
         this.galleryOpener.accept(this.setting);
      }
   }

   @Override
   public boolean isVisible() {
      return this.setting.visible.get();
   }
}
