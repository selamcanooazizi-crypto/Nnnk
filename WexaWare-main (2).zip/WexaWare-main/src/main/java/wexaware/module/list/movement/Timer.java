package wexaware.module.list.movement;

import com.google.common.eventbus.Subscribe;
import wexaware.event.list.EventTick;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.settings.SliderSetting;
import wexaware.util.math.TimerUtil;

@ModuleInformation(
   moduleName = "Timer",
   moduleDesc = "Changes the game speed",
   moduleCategory = ModuleCategory.MOVEMENT
)
public class Timer extends Module {
   private final SliderSetting speed = new SliderSetting("Speed", 2.0, 0.1F, 10.0, 0.1F);

   @Subscribe
   private void onTick(EventTick e) {
      TimerUtil.setTimer((float)this.speed.getValue());
   }

   @Override
   public void onDisable() {
      TimerUtil.setTimer(1.0F);
      super.onDisable();
   }
}
