package wexaware.module.list.player;

import com.google.common.eventbus.Subscribe;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import wexaware.event.list.EventPacket;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.ModuleSettingDefinitions;
import wexaware.module.settings.BooleanSetting;
import wexaware.util.friend.FriendRepository;

@ModuleInformation(
   moduleName = "Auto Tpaccept",
   moduleDesc = "Automatically accepts tp requests",
   moduleCategory = ModuleCategory.PLAYER
)
public class AutoTpaccept extends Module {
   private final BooleanSetting friendsOnly = ModuleSettingDefinitions.autoTpOnlyFriends();

   @Subscribe
   public void onPacket(EventPacket e) {
      if (this.mc.player != null && this.mc.world != null) {
         if (e.getPacket() instanceof GameMessageS2CPacket p
            && TpRequestRecognizer.shouldAccept(p.content().getString(), this.friendsOnly.getValue(), FriendRepository::isFriend)) {
            this.mc.getNetworkHandler().sendChatCommand("tpaccept");
         }
      }
   }
}
