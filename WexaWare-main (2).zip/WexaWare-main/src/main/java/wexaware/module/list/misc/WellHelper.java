package wexaware.module.list.misc;

import com.google.common.eventbus.Subscribe;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import wexaware.event.list.EventPacket;
import wexaware.event.list.EventTick;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.settings.BooleanSetting;

@ModuleInformation(
   moduleName = "Well Helper",
   moduleDesc = "Helper for Well",
   moduleCategory = ModuleCategory.MISC
)
public class WellHelper extends Module {
   private final BooleanSetting invseeElytraCheck = new BooleanSetting("Invsee \u044d\u043b\u0438\u0442\u0440\u044b", true);
   private final List<String> pendingPlayers = new ArrayList<>();
   private String currentInvseePlayer = null;
   private boolean waitingForInvsee = false;
   private boolean collectingPlayers = false;
   private int tickDelay = 0;
   private int collectTimeout = 0;
   private static final Pattern PLAYER_PATTERN = Pattern.compile("([a-zA-Z0-9_]{3,16})\\s+\\d+");

   @Subscribe
   private void onPacket(EventPacket e) {
      if (this.mc.player != null && this.mc.world != null) {
         if (e.getType() == EventPacket.Type.RECEIVE) {
            if (e.getPacket() instanceof GameMessageS2CPacket p && this.invseeElytraCheck.getValue()) {
               String text = p.content().getString();
               if (text.toLowerCase().contains("\u0438\u0433\u0440\u043e\u043a\u0438 \u0440\u044f\u0434\u043e\u043c")) {
                  this.pendingPlayers.clear();
                  this.currentInvseePlayer = null;
                  this.waitingForInvsee = false;
                  this.collectingPlayers = true;
                  this.collectTimeout = 6;
                  return;
               }

               if (this.collectingPlayers) {
                  Matcher matcher = PLAYER_PATTERN.matcher(text);
                  if (matcher.find()) {
                     String playerName = matcher.group(1);
                     if (!playerName.equalsIgnoreCase(this.mc.player.getName().getString()) && !this.pendingPlayers.contains(playerName)) {
                        this.pendingPlayers.add(playerName);
                     }

                     this.collectTimeout = 6;
                  }
               }
            }
         }
      }
   }

   @Subscribe
   private void onTick(EventTick e) {
      if (this.mc.player != null && this.mc.world != null && this.invseeElytraCheck.getValue()) {
         if (this.collectingPlayers) {
            this.collectTimeout--;
            if (this.collectTimeout <= 0) {
               this.collectingPlayers = false;
               if (!this.pendingPlayers.isEmpty()) {
                  this.tickDelay = 10;
               }
            }
         } else if (this.tickDelay > 0) {
            this.tickDelay--;
            if (this.tickDelay == 0 && !this.pendingPlayers.isEmpty() && !this.waitingForInvsee) {
               this.checkNextPlayer();
            }
         } else {
            if (this.waitingForInvsee && this.currentInvseePlayer != null && this.mc.currentScreen instanceof GenericContainerScreen screen) {
               boolean hasElytra = false;
               int containerSlots = ((GenericContainerScreenHandler)screen.getScreenHandler()).getRows() * 9;

               for (int i = 0; i < containerSlots; i++) {
                  Slot slot = (Slot)((GenericContainerScreenHandler)screen.getScreenHandler()).slots.get(i);
                  ItemStack stack = slot.getStack();
                  if (stack.getItem() == Items.ELYTRA) {
                     hasElytra = true;
                     break;
                  }
               }

               if (hasElytra) {
                  this.logDirect(
                     new Text[]{
                        Text.literal(this.currentInvseePlayer)
                           .formatted(Formatting.GREEN)
                           .append(
                              Text.literal(" has ELYTRA!").formatted(Formatting.LIGHT_PURPLE)
                           )
                     }
                  );
               }

               this.mc.player.closeHandledScreen();
               this.currentInvseePlayer = null;
               this.waitingForInvsee = false;
               if (!this.pendingPlayers.isEmpty()) {
                  this.tickDelay = 6;
               }
            }
         }
      }
   }

   private void checkNextPlayer() {
      if (!this.pendingPlayers.isEmpty() && this.mc.getNetworkHandler() != null) {
         this.currentInvseePlayer = this.pendingPlayers.remove(0);
         this.waitingForInvsee = true;
         this.mc.getNetworkHandler().sendChatCommand("invsee " + this.currentInvseePlayer);
      }
   }
}
