package wexaware.module.list.player;

import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.settings.BooleanSetting;
import wexaware.module.settings.ModeListSetting;

@ModuleInformation(
   moduleName = "No Push",
   moduleDesc = "Removes pushing from players and blocks",
   moduleCategory = ModuleCategory.PLAYER
)
public class NoPush extends Module {
   public final ModeListSetting objects = new ModeListSetting(
      "Objects",
      new BooleanSetting("Players", true),
      new BooleanSetting("Blocks", true)
   );
}
