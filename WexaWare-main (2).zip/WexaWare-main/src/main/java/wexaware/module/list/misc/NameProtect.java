package wexaware.module.list.misc;

import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.settings.BooleanSetting;
import wexaware.util.friend.Friend;
import wexaware.util.friend.FriendRepository;

@ModuleInformation(
   moduleName = "Streamer Mode",
   moduleDesc = "Hides player nicknames",
   moduleCategory = ModuleCategory.MISC
)
public class NameProtect extends Module {
   public final BooleanSetting hideFriends = new BooleanSetting("Hide Friends", false);

   public String getCustomName() {
      return this.isEnabled() ? "wexaware" : this.mc.player.getNameForScoreboard();
   }

   public String getCustomName(String originalName) {
      if (this.isEnabled() && this.mc.player != null) {
         String me = this.mc.player.getNameForScoreboard();
         if (originalName.contains(me)) {
            return originalName.replace(me, "wexaware");
         } else {
            if (this.hideFriends.getValue()) {
               for (Friend friend : FriendRepository.getFriends()) {
                  if (originalName.contains(friend.name())) {
                     return originalName.replace(friend.name(), "wexaware");
                  }
               }
            }

            return originalName;
         }
      } else {
         return originalName;
      }
   }
}
