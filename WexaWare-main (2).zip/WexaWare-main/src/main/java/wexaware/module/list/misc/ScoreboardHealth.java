package wexaware.module.list.misc;

import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;

@ModuleInformation(
   moduleName = "Scoreboard Health",
   moduleDesc = "Reads player HP from the scoreboard",
   moduleCategory = ModuleCategory.MISC
)
public class ScoreboardHealth extends Module {
}
