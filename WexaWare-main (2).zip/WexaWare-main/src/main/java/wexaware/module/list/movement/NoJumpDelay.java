package wexaware.module.list.movement;

import com.google.common.eventbus.Subscribe;
import wexaware.event.list.EventTick;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;

@ModuleInformation(
   moduleName = "No Jump Delay",
   moduleDesc = "Removes the delay between jumps",
   moduleCategory = ModuleCategory.MISC
)
public class NoJumpDelay extends Module {
   @Subscribe
   private void onUpdate(EventTick e) {
      if (this.mc.player != null && this.mc.world != null) {
         this.mc.player.jumpingCooldown = 0;
      }
   }
}
