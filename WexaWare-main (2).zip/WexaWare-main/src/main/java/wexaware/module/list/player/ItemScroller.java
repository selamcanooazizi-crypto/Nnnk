package wexaware.module.list.player;

import wexaware.module.Module;

public class ItemScroller extends Module {
}
