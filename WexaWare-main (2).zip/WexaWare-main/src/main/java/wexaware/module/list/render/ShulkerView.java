package wexaware.module.list.render;

import com.google.common.eventbus.Subscribe;
import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import wexaware.event.list.EventHUD;
import wexaware.event.list.EventHandledScreen;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.settings.BooleanSetting;
import wexaware.module.settings.SliderSetting;
import wexaware.util.render.math.ProjectionUtil;
import wexaware.util.render.providers.ColorProvider;
import wexaware.util.render.renderers.DrawUtil;

@ModuleInformation(
   moduleName = "ShulkerView",
   moduleDesc = "Shows the contents of shulkers and containers",
   moduleCategory = ModuleCategory.RENDER
)
public class ShulkerView extends Module {
   private final BooleanSetting showHover = new BooleanSetting("In Inventory", true);
   private final BooleanSetting showGround = new BooleanSetting("On Ground", true);
   private final SliderSetting scale = new SliderSetting("Scale", 0.75, 0.4, 1.5, 0.05);
   private static final int CELL = 18;
   private static final int COLS = 9;
   private static final float PAD = 3.0F;

   @Subscribe
   private void onHandledScreen(EventHandledScreen e) {
      if (this.showHover.getValue()) {
         Slot slot = e.getSlotHover();
         if (slot != null && slot.hasStack()) {
            List<ItemStack> contents = this.getContents(slot.getStack());
            if (!contents.isEmpty()) {
               float sc = this.scale.getFloatValue();
               float w = 168.0F * sc;
               float h = ((float)(this.rows(contents.size()) * 18) + 6.0F) * sc;
               float x = (float)(e.getMouseX() + 8);
               float y = (float)(e.getMouseY() + 8);
               if (x + w > (float)this.mc.getWindow().getScaledWidth()) {
                  x = (float)e.getMouseX() - w - 8.0F;
               }

               if (y + h > (float)this.mc.getWindow().getScaledHeight()) {
                  y = (float)e.getMouseY() - h - 8.0F;
               }

               this.draw(e.getDrawContext(), contents, x, y, sc);
            }
         }
      }
   }

   @Subscribe
   private void onHud(EventHUD e) {
      if (this.showGround.getValue() && this.mc.world != null) {
         for (Entity entity : this.mc.world.getEntities()) {
            if (entity instanceof ItemEntity) {
               ItemEntity item = (ItemEntity)entity;
               List<ItemStack> contents = this.getContents(item.getStack());
               if (!contents.isEmpty()) {
                  Vector2f pos = ProjectionUtil.project(entity.getPos().add(0.0, (double)entity.getHeight() + 0.3, 0.0));
                  if (pos.getX() != Float.MAX_VALUE) {
                     float sc = this.scale.getFloatValue() * 0.6F;
                     float w = 168.0F * sc;
                     this.draw(e.getDrawContext(), contents, pos.getX() - w / 2.0F, pos.getY(), sc);
                  }
               }
            }
         }
      }
   }

   private List<ItemStack> getContents(ItemStack stack) {
      ContainerComponent component = (ContainerComponent)stack.get(DataComponentTypes.CONTAINER);
      return component != null ? component.stream().toList() : List.of();
   }

   private int rows(int count) {
      return Math.max(1, (int)Math.ceil((double)count / 9.0));
   }

   private void draw(DrawContext ctx, List<ItemStack> stacks, float x, float y, float sc) {
      float w = 168.0F * sc;
      float h = ((float)(this.rows(stacks.size()) * 18) + 6.0F) * sc;
      DrawUtil.drawRound(x, y, w, h, 4.0F, ColorProvider.rgba(18, 18, 24, 225.0F));
      ctx.getMatrices().push();
      ctx.getMatrices().translate(x + 3.0F * sc, y + 3.0F * sc, 400.0F);
      ctx.getMatrices().scale(sc, sc, 1.0F);
      int i = 0;

      for (ItemStack stack : stacks) {
         int cx = i % 9 * 18;
         int cy = i / 9 * 18;
         ctx.drawItem(stack, cx, cy);
         ctx.drawStackOverlay(this.mc.textRenderer, stack, cx, cy);
         i++;
      }

      ctx.getMatrices().pop();
   }
}
