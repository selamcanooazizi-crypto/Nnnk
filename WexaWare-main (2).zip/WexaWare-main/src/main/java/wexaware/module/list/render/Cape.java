package wexaware.module.list.render;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import wexaware.WexaWare;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.module.settings.BooleanSetting;
import wexaware.module.settings.ModeListSetting;
import wexaware.util.friend.FriendRepository;

@ModuleInformation(
   moduleName = "Cape",
   moduleDesc = "Custom cape for the player",
   moduleCategory = ModuleCategory.RENDER
)
public class Cape extends Module {
   private final ModeListSetting targets = new ModeListSetting(
      "Apply To",
      new BooleanSetting("Self", true),
      new BooleanSetting("Friends", true)
   );

   public static Cape getInstance() {
      return WexaWare.getInstance().getModuleStorage().get(Cape.class);
   }

   public boolean shouldRenderCape(AbstractClientPlayerEntity player) {
      if (this.isEnabled() && player != null) {
         boolean isSelf = player == this.mc.player;
         boolean isFriend = FriendRepository.isFriend(player.getNameForScoreboard());
         boolean selfEnabled = this.targets.isEnabled("Self");
         boolean friendsEnabled = this.targets.isEnabled("Friends");
         if (isSelf) {
            return selfEnabled;
         } else {
            return isFriend ? friendsEnabled : false;
         }
      } else {
         return false;
      }
   }
}
