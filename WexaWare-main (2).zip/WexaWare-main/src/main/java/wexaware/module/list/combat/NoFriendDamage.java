package wexaware.module.list.combat;

import com.google.common.eventbus.Subscribe;
import wexaware.event.list.EventAttack;
import wexaware.module.Module;
import wexaware.module.ModuleCategory;
import wexaware.module.ModuleInformation;
import wexaware.util.friend.Friend;
import wexaware.util.friend.FriendRepository;

@ModuleInformation(
   moduleName = "No Friend Damage",
   moduleDesc = "Does not attack friends from the list",
   moduleCategory = ModuleCategory.COMBAT
)
public class NoFriendDamage extends Module {
   @Subscribe
   private void onAttack(EventAttack e) {
      for (Friend friend : FriendRepository.getFriends()) {
         if (e.getEntity() != this.mc.player && e.getEntity().getNameForScoreboard().equals(friend.name())) {
            e.cancelEvent();
         }
      }
   }
}
