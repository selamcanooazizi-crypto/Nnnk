package wexaware.module;

public enum ModuleCategory {
   COMBAT,
   MOVEMENT,
   RENDER,
   PLAYER,
   MISC;
}
