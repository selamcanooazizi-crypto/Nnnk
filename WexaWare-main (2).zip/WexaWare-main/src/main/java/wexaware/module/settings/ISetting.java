package wexaware.module.settings;

import java.util.function.Supplier;

public interface ISetting {
   Setting setVisible(Supplier<Boolean> var1);
}
