package wexaware.module;

import com.google.common.eventbus.Subscribe;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Generated;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import wexaware.WexaWare;
import wexaware.event.EventGameUpdate;
import wexaware.event.list.EventHUD;
import wexaware.event.list.EventKeyInput;
import wexaware.event.list.EventTick;
import wexaware.module.list.combat.AntiBot;
import wexaware.module.list.combat.AutoArmor;
import wexaware.module.list.combat.AutoExplosion;
import wexaware.module.list.combat.AutoPotion;
import wexaware.module.list.combat.AutoSwap;
import wexaware.module.list.combat.AutoTotem;
import wexaware.module.list.combat.AutoTrap;
import wexaware.module.list.combat.CrystalAura;
import wexaware.module.list.combat.CrystalSpammer;
import wexaware.module.list.combat.KillAura;
import wexaware.module.list.combat.WexaWareAura;
import wexaware.module.list.combat.ElytraTarget2;
import wexaware.module.list.combat.MaceTarget;
import wexaware.module.list.combat.NoEntityTrace;
import wexaware.module.list.combat.NoFriendDamage;
import wexaware.module.list.combat.TargetPearl;
import wexaware.module.list.combat.TriggerBot;
import wexaware.module.list.combat.Velocity;
import wexaware.module.list.misc.AutoDuel;
import wexaware.module.list.misc.ChestStealer;
import wexaware.module.list.misc.CrystalOptimizer;
import wexaware.module.list.misc.NameProtect;
import wexaware.module.list.misc.ScoreboardHealth;
import wexaware.module.list.misc.ServerJoiner;
import wexaware.module.list.misc.UseTracker;
import wexaware.module.list.movement.AirStuck;
import wexaware.module.list.movement.DogFly;
import wexaware.module.list.movement.DragonFly;
import wexaware.module.list.movement.ElytraBooster;
import wexaware.module.list.movement.ElytraFlight;
import wexaware.module.list.movement.ElytraMotion;
import wexaware.module.list.movement.ElytraTarget;
import wexaware.module.list.movement.GrimGlide;
import wexaware.module.list.movement.GuiMove;
import wexaware.module.list.movement.NoJumpDelay;
import wexaware.module.list.movement.NoSlow;
import wexaware.module.list.movement.NoWeb;
import wexaware.module.list.movement.Speed;
import wexaware.module.list.movement.Sprint;
import wexaware.module.list.movement.Strafe;
import wexaware.module.list.movement.Timer;
import wexaware.module.list.player.AutoEat;
import wexaware.module.list.player.AutoLeave;
import wexaware.module.list.player.AutoTool;
import wexaware.module.list.player.AutoTpaccept;
import wexaware.module.list.player.ClickPearl;
import wexaware.module.list.player.DeathCoords;
import wexaware.module.list.player.ElytraHelper;
import wexaware.module.list.player.FakePlayer;
import wexaware.module.list.player.FastExp;
import wexaware.module.list.player.FreeCamera;
import wexaware.module.list.player.LockSlot;
import wexaware.module.list.player.NoPush;
import wexaware.module.list.player.RPSpoofer;
import wexaware.module.list.player.ServerHelper;
import wexaware.module.list.player.TapeMouse;
import wexaware.module.list.player.TeleportBack;
import wexaware.module.list.player.TeleportExploit;
import wexaware.module.list.render.Ambience;
import wexaware.module.list.render.Arrows;
import wexaware.module.list.render.BlockOverlay;
import wexaware.module.list.render.Cape;
import wexaware.module.list.render.Chams;
import wexaware.module.list.render.ClickGui;
import wexaware.module.list.render.ClientSounds;
import wexaware.module.list.render.FireFly;
import wexaware.module.list.render.FreeLook;
import wexaware.module.list.render.FullBright;
import wexaware.module.list.render.GlassHands;
import wexaware.module.list.render.GlowEsp;
import wexaware.module.list.render.HitBubbles;
import wexaware.module.list.render.HitIndicator;
import wexaware.module.list.render.ItemReplacer;
import wexaware.module.list.render.KillEffect;
import wexaware.module.list.render.LineGlyphs;
import wexaware.module.list.render.NameTags;
import wexaware.module.list.render.NoRender;
import wexaware.module.list.render.Particles;
import wexaware.module.list.render.Predictions;
import wexaware.module.list.render.SeeInvisible;
import wexaware.module.list.render.ShulkerView;
import wexaware.module.list.render.SoulESP;
import wexaware.module.list.render.SwingAnimations;
import wexaware.module.list.render.TargetESP;
import wexaware.module.list.render.Tracers;
import wexaware.module.list.render.Trails;
import wexaware.module.list.render.UseIndicator;
import wexaware.module.list.render.ViewModel;
import wexaware.module.list.render.Wings;
import wexaware.module.list.render.hud.Interface;
import wexaware.module.settings.BooleanSetting;
import wexaware.module.settings.Setting;
import wexaware.module.settings.ThemeSetting;
import wexaware.util.IMinecraft;
import wexaware.util.base.Instance;
import wexaware.util.player.other.SlownessManager;
import wexaware.util.rotation.Rotation;
import wexaware.util.rotation.RotationComponent;

public class ModuleStorage implements IMinecraft {
   private final List<Module> modules = new ArrayList<>();
   private float speedAcceleration;
   private float randomness;

   public void injectRegisterModules() {
      this.modules
         .addAll(
            List.of(
               new FullBright(),
               new ClickGui(),
               new Sprint(),
               new TriggerBot(),
               new NoRender(),
               new KillAura(),
               new WexaWareAura(),
               new NameTags(),
               new TargetESP(),
               new NoPush(),
               new SoulESP(),
               new NoJumpDelay(),
               new TeleportBack(),
               new ElytraHelper(),
               new AutoTotem(),
               new ClickPearl(),
               new UseTracker(),
               new CrystalAura(),
               new ClientSounds(),
               new NoFriendDamage(),
               new ElytraBooster(),
               new FreeCamera(),
               new SwingAnimations(),
               new Predictions(),
               new DogFly(),
               new AutoTpaccept(),
               new RPSpoofer(),
               new FireFly(),
               new AntiBot(),
               new AutoExplosion(),
               new DeathCoords(),
               new CrystalOptimizer(),
               new GuiMove(),
               new Tracers(),
               new ElytraMotion(),
               new Velocity(),
               new ElytraFlight(),
               new ViewModel(),
               new GlassHands(),
               new ItemReplacer(),
               new KillEffect(),
               new AutoArmor(),
               new Speed(),
               new AutoTool(),
               new TapeMouse(),
               new Ambience(),
               new BlockOverlay(),
               new FreeLook(),
               new Chams(),
               new GlowEsp(),
               new Trails(),
               new FastExp(),
               new NameProtect(),
               new CrystalSpammer(),
               new AirStuck(),
               new AutoSwap(),
               new NoSlow(),
               new NoWeb(),
               new FakePlayer(),
               new Interface(),
               new AutoEat(),
               new AutoLeave(),
               new Wings(),
               new ScoreboardHealth(),
               new AutoPotion(),
               new Cape(),
               new AutoDuel(),
               new DragonFly(),
               new Strafe(),
               new ChestStealer(),
               new SeeInvisible(),
               new ShulkerView(),
               new ServerJoiner(),
               new UseIndicator(),
               new ServerHelper(),
               new Particles(),
               new Arrows(),
               new TeleportExploit(),
               new AutoTrap(),
               new TargetPearl(),
               new LineGlyphs(),
               new HitIndicator(),
               new GrimGlide(),
               new Timer(),
               new MaceTarget(),
               new NoEntityTrace(),
               new LockSlot(),
               new ElytraTarget(),
               new ElytraTarget2(),
               new HitBubbles()
            )
         );
      WexaWare.getInstance().getEventBus().register(this);
   }

   public <T extends Module> T get(String name) {
      return this.modules.stream().filter(module -> module.getName().equalsIgnoreCase(name)).map(module -> (T)module).findFirst().orElse(null);
   }

   public <T extends Module> T get(Class<T> clazz) {
      return this.modules.stream().filter(module -> clazz.isAssignableFrom(module.getClass())).map(clazz::cast).findFirst().orElse(null);
   }

   public List<Module> get(ModuleCategory category) {
      return this.modules.stream().filter(module -> module.getCategory() == category).collect(Collectors.toList());
   }

   @Subscribe
   private void onGameUpdate(EventGameUpdate e) {
      if (mc.player != null) {
         if (!SlownessManager.slowTasksIsEmpty()) {
            SlownessManager.updateSlowTasks();
         }

         if (!SlownessManager.timeTasksIsEmpty()) {
            SlownessManager.updateTimeTasks(false);
         }

         KillAura aura = this.get(KillAura.class);
         if (!aura.isEnabled() || aura.getTarget() == null) {
            if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
               aura.lastYaw = mc.gameRenderer.getCamera().getYaw() - 180.0F;
               aura.lastPitch = -mc.gameRenderer.getCamera().getPitch();
            } else {
               aura.lastYaw = mc.gameRenderer.getCamera().getYaw();
               aura.lastPitch = mc.gameRenderer.getCamera().getPitch();
            }

            if (aura.rotation.is("Vanilla") || Instance.get(FreeLook.class).isActive()) {
               return;
            }

            this.updateBackwardsOther();
         }
      }
   }

   @Subscribe
   private void onRender(EventHUD ignored) {
      for (Module module : this.getModules()) {
         module.getAnimation().run(module.isEnabled());

         for (Setting setting : module.getSettings()) {
            if (setting instanceof BooleanSetting b) {
               b.getAnimation().run(b.getValue());
            }

            if (setting instanceof ThemeSetting t) {
               t.getValue().animation.run(1.0F);
            }
         }
      }
   }

   @Subscribe
   private void onKey(EventKeyInput e) {
      if (e.getAction() != 0) {
         for (Module module : this.getModules()) {
            module.getSettings().stream().filter(setting -> {
               if (setting instanceof BooleanSetting b && e.getKey() == b.getKey()) {
                  return true;
               }

               return false;
            }).forEach(setting -> ((BooleanSetting)setting).toggle());
         }
      }
   }

   @Subscribe
   private void onUpdate(EventTick ignored) {
      if (!SlownessManager.timeTasksIsEmpty()) {
         SlownessManager.updateTimeTasks(true);
      }

      if (mc.player != null) {
      }
   }

   private void updateBackwardsOther() {
      if (mc.player.isGliding()) {
         this.speedAcceleration += 0.06F;
      } else {
         this.speedAcceleration += 0.006F;
      }

      this.get(KillAura.class).speedAcceleration = 0.0F;
      Rotation angle = new Rotation(mc.gameRenderer.getCamera().getYaw(), mc.gameRenderer.getCamera().getPitch());
      float deltaYaw = MathHelper.wrapDegrees(angle.getYaw() - mc.player.getYaw());
      float deltaPitch = angle.getPitch() - mc.player.getPitch();
      if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
         deltaYaw = MathHelper.wrapDegrees(angle.getYaw() - 180.0F - mc.player.getYaw());
         deltaPitch = MathHelper.wrapDegrees(-angle.getPitch() - mc.player.getPitch());
      }

      float smooth = Math.max(this.speedAcceleration, 0.0F);
      float newYaw = mc.player.getYaw() + deltaYaw * Math.min(Math.max(smooth, 0.0F), 1.0F);
      float newPitch = mc.player.getPitch() + deltaPitch * Math.min(Math.max(smooth / 2.0F, 0.0F), 1.0F);
      Rotation smoothRot = new Rotation(newYaw, newPitch);
      RotationComponent.update(smoothRot, 360.0F, 360.0F, 360.0F, 360.0F, 0, 2, false);
   }

   @Generated
   public List<Module> getModules() {
      return this.modules;
   }

   @Generated
   public float getSpeedAcceleration() {
      return this.speedAcceleration;
   }

   @Generated
   public float getRandomness() {
      return this.randomness;
   }

   @Generated
   public void setSpeedAcceleration(float speedAcceleration) {
      this.speedAcceleration = speedAcceleration;
   }

   @Generated
   public void setRandomness(float randomness) {
      this.randomness = randomness;
   }
}
