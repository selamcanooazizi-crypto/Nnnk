package wexaware;

import com.google.common.eventbus.EventBus;
import com.google.common.eventbus.Subscribe;
import java.io.File;
import lombok.Generated;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.MinecraftClient;
import wexaware.event.list.EventKeyInput;
import wexaware.module.Module;
import wexaware.module.ModuleStorage;
import wexaware.ui.ThemeEditor;
import wexaware.util.commands.CommandDispatcher;
import wexaware.util.commands.manager.CommandRepository;
import wexaware.util.config.ConfigManager;
import wexaware.util.draggable.DragManager;
import wexaware.util.friend.FriendRepository;
import wexaware.util.macro.MacroRepository;
import wexaware.util.math.TPSGetter;
import wexaware.util.player.combat.IdealHitUtils;
import wexaware.util.player.other.ServerManager;
import wexaware.util.rotation.ComponentManager;
import wexaware.util.script.ScriptManager;
import wexaware.util.staff.StaffManager;

public class WexaWare implements ModInitializer {
   private static WexaWare instance;
   private final EventBus eventBus;
   private final ModuleStorage moduleStorage;
   private final ComponentManager componentManager;
   private final DragManager dragManager;
   private final CommandRepository commandRepository;
   private final MacroRepository macroRepository;
   private final ConfigManager configManager;
   private final CommandDispatcher commandDispatcher;
   private final StaffManager staffManager;
   private final ServerManager serverManager;
   private final TPSGetter tpsGetter;
   private final IdealHitUtils idealHitUtils;
   private final ScriptManager scriptManager;

   public WexaWare() {
      instance = this;
      this.eventBus = new EventBus();
      this.eventBus.register(this);
      this.moduleStorage = new ModuleStorage();
      this.componentManager = new ComponentManager();
      this.dragManager = new DragManager();
      this.macroRepository = new MacroRepository();
      this.configManager = new ConfigManager();
      this.staffManager = new StaffManager();
      this.staffManager.load();
      this.commandRepository = new CommandRepository();
      this.commandDispatcher = new CommandDispatcher();
      this.serverManager = new ServerManager();
      this.tpsGetter = new TPSGetter();
      this.idealHitUtils = new IdealHitUtils();
      this.scriptManager = new ScriptManager();
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         ConfigManager.save("autocfg");
         this.getDragManager().saveDraggables();
         this.getMacroRepository().save();
         FriendRepository.save();
         this.staffManager.save();
      }));
      File dir = new File("wexaware/configs/");
      if (!dir.exists()) {
         dir.mkdirs();
      }
   }

   public static WexaWare getInstance() {
      return instance == null ? new WexaWare() : instance;
   }

   public void onInitialize() {
      this.getModuleStorage().injectRegisterModules();
      this.componentManager.init();
      this.dragManager.load();
      this.macroRepository.load();
      FriendRepository.load();
      ConfigManager.load("autocfg");
      ThemeEditor.applyStartupTheme();
   }

   @Subscribe
   private void onModuleKeyPressed(EventKeyInput event) {
      for (Module module : this.getModuleStorage().getModules()) {
         if (event.getAction() == 1 && MinecraftClient.getInstance().currentScreen == null && module.getKey() == event.getKey()) {
            module.toggle();
         }
      }
   }

   @Generated
   public EventBus getEventBus() {
      return this.eventBus;
   }

   @Generated
   public ModuleStorage getModuleStorage() {
      return this.moduleStorage;
   }

   @Generated
   public ComponentManager getComponentManager() {
      return this.componentManager;
   }

   @Generated
   public DragManager getDragManager() {
      return this.dragManager;
   }

   @Generated
   public CommandRepository getCommandRepository() {
      return this.commandRepository;
   }

   @Generated
   public MacroRepository getMacroRepository() {
      return this.macroRepository;
   }

   @Generated
   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   @Generated
   public CommandDispatcher getCommandDispatcher() {
      return this.commandDispatcher;
   }

   @Generated
   public StaffManager getStaffManager() {
      return this.staffManager;
   }

   @Generated
   public ServerManager getServerManager() {
      return this.serverManager;
   }

   @Generated
   public TPSGetter getTpsGetter() {
      return this.tpsGetter;
   }

   @Generated
   public IdealHitUtils getIdealHitUtils() {
      return this.idealHitUtils;
   }

   @Generated
   public ScriptManager getScriptManager() {
      return this.scriptManager;
   }
}
