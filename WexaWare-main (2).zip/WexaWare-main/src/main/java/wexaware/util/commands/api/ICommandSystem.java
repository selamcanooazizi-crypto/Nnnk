package wexaware.util.commands.api;

import wexaware.util.commands.api.argparser.IArgParserManager;

public interface ICommandSystem {
   IArgParserManager getParserManager();
}
