package wexaware.util.commands;

import wexaware.util.commands.api.ICommandSystem;
import wexaware.util.commands.api.argparser.IArgParserManager;
import wexaware.util.commands.argparser.ArgParserManager;

public enum CommandSystem implements ICommandSystem {
   INSTANCE;

   @Override
   public IArgParserManager getParserManager() {
      return ArgParserManager.INSTANCE;
   }
}
