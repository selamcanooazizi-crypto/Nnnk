package wexaware.util.commands.api.datatypes;

import java.util.stream.Stream;
import wexaware.util.IMinecraft;
import wexaware.util.commands.api.exception.CommandException;

public interface IDatatype extends IMinecraft {
   Stream<String> tabComplete(IDatatypeContext var1) throws CommandException;
}
