package wexaware.util.commands.api.datatypes;

import wexaware.util.commands.api.exception.CommandException;

public interface IDatatypePost<T, O> extends IDatatype {
   T apply(IDatatypeContext var1, O var2) throws CommandException;
}
