package wexaware.util.commands.api.datatypes;

import wexaware.util.commands.api.argument.IArgConsumer;

public interface IDatatypeContext {
   IArgConsumer getConsumer();
}
