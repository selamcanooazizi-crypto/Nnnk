package wexaware.util.commands.defaults;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import wexaware.WexaWare;
import wexaware.util.commands.api.ICommand;

public final class DefaultCommands {
   public static List<ICommand> createAll() {
      List<ICommand> commands = new ArrayList<>(
         Arrays.asList(
            new CfgCommand(),
            new RotationCommand(),
            new HelpCommand(WexaWare.getInstance()),
            new MacroCommand(WexaWare.getInstance()),
            new BindCommand(WexaWare.getInstance()),
            new FriendCommand(WexaWare.getInstance()),
            new StaffCommand(WexaWare.getInstance()),
            new VClipCommand(),
            new TpCommand(),
            new PartyCommand(),
            new GpsCommand(),
            new AICommand(),
            new BotCommand()
         )
      );
      return Collections.unmodifiableList(commands);
   }
}
