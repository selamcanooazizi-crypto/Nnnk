package wexaware.util.rotation;

import wexaware.util.IMinecraft;

public abstract class Component implements IMinecraft {
}
