package wexaware.util.render.renderers.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexFormat.DrawMode;
import org.joml.Matrix4f;
import wexaware.util.render.builders.states.QuadColorState;
import wexaware.util.render.builders.states.QuadRadiusState;
import wexaware.util.render.builders.states.SizeState;
import wexaware.util.render.providers.ResourceProvider;
import wexaware.util.render.renderers.IRenderer;

public record BuiltRectangle(SizeState size, QuadRadiusState radius, QuadColorState color, float smoothness) implements IRenderer {
   private static final ShaderProgramKey RECTANGLE_SHADER_KEY = new ShaderProgramKey(
      ResourceProvider.getShaderIdentifier("rectangle"), VertexFormats.POSITION_COLOR, Defines.EMPTY
   );

   @Override
   public void render(Matrix4f matrix, float x, float y, float z) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      float width = this.size.width();
      float height = this.size.height();
      ShaderProgram shader = RenderSystem.setShader(RECTANGLE_SHADER_KEY);
      shader.getUniform("Size").set(width, height);
      shader.getUniform("Radius").set(this.radius.radius1(), this.radius.radius2(), this.radius.radius3(), this.radius.radius4());
      shader.getUniform("Smoothness").set(this.smoothness);
      BufferBuilder builder = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_COLOR);
      builder.vertex(matrix, x, y, z).color(this.color.color1());
      builder.vertex(matrix, x, y + height, z).color(this.color.color2());
      builder.vertex(matrix, x + width, y + height, z).color(this.color.color3());
      builder.vertex(matrix, x + width, y, z).color(this.color.color4());
      BufferRenderer.drawWithGlobalProgram(builder.end());
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }
}
