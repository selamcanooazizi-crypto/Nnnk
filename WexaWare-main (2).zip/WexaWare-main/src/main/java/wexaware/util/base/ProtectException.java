package wexaware.util.base;

public class ProtectException extends Exception {
}
