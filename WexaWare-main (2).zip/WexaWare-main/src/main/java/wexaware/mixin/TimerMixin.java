package wexaware.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import wexaware.util.math.TimerUtil;

@Mixin({MinecraftClient.class})
public abstract class TimerMixin {
   @Unique
   private long wexawareLastRealTime = 0L;
   @Unique
   private long wexawareFakeTime = 0L;

   @ModifyArg(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/RenderTickCounter$Dynamic;beginRenderTick(JZ)I"
      ),
      index = 0
   )
   private long modifyRenderTime(long currentTime) {
      if (TimerUtil.speed == 1.0F) {
         this.wexawareLastRealTime = currentTime;
         this.wexawareFakeTime = currentTime;
         return currentTime;
      } else if (this.wexawareLastRealTime == 0L) {
         this.wexawareLastRealTime = currentTime;
         this.wexawareFakeTime = currentTime;
         return currentTime;
      } else {
         long realElapsed = currentTime - this.wexawareLastRealTime;
         this.wexawareLastRealTime = currentTime;
         this.wexawareFakeTime = this.wexawareFakeTime + (long)((double)realElapsed * (double)TimerUtil.speed);
         return this.wexawareFakeTime;
      }
   }
}
